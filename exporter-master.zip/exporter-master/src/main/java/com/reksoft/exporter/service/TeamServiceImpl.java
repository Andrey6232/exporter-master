package com.reksoft.exporter.service;

import com.reksoft.exporter.model.Team;
import com.reksoft.exporter.repository.TeamApiRepository;
import com.reksoft.exporter.repository.dto.PlayerDto;
import com.reksoft.exporter.repository.dto.TeamViewDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TeamServiceImpl implements TeamService {

    private final TeamApiRepository teamApiRepository;

    @Override
    public List<Team> getTeams() {
        List<TeamViewDto> teamViewDtos = teamApiRepository.getTeams();
        return teamViewDtos.stream().map(this::map).toList();
    }

    private Team map(TeamViewDto dto) {
        Team team = new Team();
        team.setId(dto.getId());
        team.setTeamName(dto.getName());

        List<String> playerNames = dto.getPlayers().stream()
                .map(player -> player.getName() + " " + player.getSurname())
                .collect(Collectors.toList());
        team.setPlayers(playerNames);

        return team;
    }
}