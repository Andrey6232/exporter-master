package com.reksoft.exporter.service;

import com.reksoft.exporter.model.Player;
import com.reksoft.exporter.repository.PlayerApiRepository;
import com.reksoft.exporter.repository.dto.PlayerViewDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PlayerServiceImpl implements PlayerService {

    private final PlayerApiRepository playerApiRepository;

    @Override
    public List<Player> getPlayers() {
        List<PlayerViewDto> playerViewDtos = playerApiRepository.getPlayers();
        return playerViewDtos.stream().map(this::map).toList();
    }

    private Player map(PlayerViewDto dto) {
        Player player = new Player();
        player.setId(dto.getId());
        player.setCountry(dto.getCountry());
        player.setNickname(dto.getNickName());

        String combinedName = dto.getName() + " " + dto.getSurname();
        player.setCombinedName(combinedName);

        String fullName = dto.getName() + " \"" + dto.getNickName() + "\" " + dto.getSurname();
        player.setFullName(fullName);

        player.setTeamName(dto.getTeamName());
        return player;
    }
}